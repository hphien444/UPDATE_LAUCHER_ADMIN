WESTSIDE ADMIN - THU THAP CRASH DAY DU (KHONG PHAI BAN FIX)

Ket qua kiem tra dump 2026-09-19 16:43:15:
- May da nhan ban va truoc; khong phai loi chua update bootstrap.
- Crash moi: washington-twenty-july, game build 3258, RVA 0x2FB6E8.
- Game doc [RAX+0x290] voi RAX=0. Dump nho khong luu doi tuong/getter
  can thiet de tim nguon goc con tro rong. Chua chung minh duoc loi goc.
- KHONG them ban va doan mo va KHONG thay doi ban production tren GitHub.

Lam tren DUNG MAY dang crash (khong phai may build neu la hai may khac):
1. Dong WESTSIDE ADMIN va cua so bao crash. Giai nen goi nay.
2. Chay 01_ENABLE_FULL_DUMP.cmd. Script chi dung tuy chon san co cua
   launcher, sao luu CitizenFX.ini, bat full dump va tam tat auto-upload.
   Khong xoa cache, khong tat anti-cheat, khong sua DLL, khong stop process.
3. Mo lai ADMIN va lap lai thao tac gay crash mot lan. Cho ghi dump xong.
   Can vai GB dung luong trong (co the nhieu hon tuy RAM game dang dung).
4. Giu file MOI *-full.dmp trong thu muc crashes va CitizenFX_log_*.log
   cung lan chay trong thu muc logs, canh CitizenFX.ini cua runtime.
   Neu khong thay *-full.dmp, bao lai; zip crash nho nhu truoc la chua du.
5. Dong game/cua so crash, chay 02_RESTORE_SETTINGS.cmd de khoi phuc
   dung hai tuy chon cu. Cac thay doi INI khac van duoc giu lai.
6. Cung cap file full dump rieng tu va mo ta crash o buoc nao:
   dang load, chon nhan vat, spawn, doi skin, hay dang choi.

BAO MAT: full dump co the chua token dang nhap, chat va du lieu ca nhan.
Khong dang dump, log, CitizenFX.ini hay file .bak len GitHub cong khai.
Goi nay KHONG tu gui bat ky file nao. Khong can quyen Administrator.
PowerShell ExecutionPolicy Bypass chi ap dung cho process chay script nay;
khong thay doi chinh sach PowerShell toan may.

Neu script khong tim thay INI, dung PowerShell voi duong dan thuc:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Collect-AdminCrash.ps1 -Action Enable -IniPath "D:\DUONG_DAN_ADMIN\CitizenFX.ini"
Khi restore dung lai cung -IniPath va -Action Restore.
Khong tro vao INI cua TEST/CITY hay tao INI moi o thu muc tuy y.

Kiem thu: helper da qua 6 nhom test voi INI gia lap (khong chay game).
Ban production van la commit 5a322ef5ea5a32533feff3466601a8650d5c2e32.
Chua co ban sua goc duoc xac minh, chua co runtime moi duoc build/push.
