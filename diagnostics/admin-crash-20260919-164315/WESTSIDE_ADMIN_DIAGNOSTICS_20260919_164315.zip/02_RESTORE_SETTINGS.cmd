@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-AdminCrash.ps1" -Action Restore
set "result=%errorlevel%"
echo.
pause
exit /b %result%
