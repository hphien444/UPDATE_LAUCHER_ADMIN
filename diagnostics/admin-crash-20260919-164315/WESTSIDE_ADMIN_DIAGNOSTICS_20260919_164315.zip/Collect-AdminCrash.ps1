param(
    [ValidateSet('Enable', 'Restore', 'Status')]
    [string]$Action = 'Status',
    [string]$IniPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (-not $IniPath) {
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'WESTSIDE CITY ADMIN\WESTSIDE CITY.app\CitizenFX.ini'),
        (Join-Path $env:LOCALAPPDATA 'WESTSIDE CITY ADMIN\CitizenFX.ini')
    ) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf }
    if (@($candidates).Count -ne 1) {
        throw 'Cannot identify the ADMIN CitizenFX.ini. Run this on the crashing PC, or pass -IniPath with its exact path.'
    }
    $IniPath = @($candidates)[0]
}

$IniPath = (Resolve-Path -LiteralPath $IniPath).ProviderPath
if ([IO.Path]::GetFileName($IniPath) -ine 'CitizenFX.ini') {
    throw 'Expected an existing CitizenFX.ini; no other files will be edited.'
}

if (-not ('WestsideCrashIni' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
public static class WestsideCrashIni
{
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern uint GetPrivateProfileString(string section, string key,
        string fallback, StringBuilder result, uint size, string path);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    static extern bool WritePrivateProfileString(string section, string key,
        string value, string path);
    public static string Read(string path, string key)
    {
        const string missing = "__WESTSIDE_MISSING_59F3D9C8__";
        var result = new StringBuilder(32768);
        GetPrivateProfileString("Game", key, missing, result, 32768, path);
        return result.ToString() == missing ? null : result.ToString();
    }
    public static void Write(string path, string key, string value, bool remove)
    {
        if (!WritePrivateProfileString("Game", key, remove ? null : value, path))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        if (Read(path, key) != (remove ? null : value))
            throw new InvalidOperationException("INI verification failed for " + key);
    }
}
'@
}

$keys = @('EnableFullMemoryDump', 'DisableCrashUpload')
$statePath = $IniPath + '.westside-dump-state.json'
if ($Action -eq 'Status') {
    foreach ($key in $keys) {
        $value = [WestsideCrashIni]::Read($IniPath, $key)
        if ($null -eq $value) { $value = '(not set)' }
        Write-Output "$key=$value"
    }
    Write-Output "Restore state exists: $(Test-Path -LiteralPath $statePath)"
    return
}

if (Get-Process | Where-Object { $_.ProcessName -like 'WESTSIDE*' }) {
    throw 'Close WESTSIDE and its crash dialog before changing diagnostic settings. No processes were stopped.'
}

if ($Action -eq 'Enable') {
    if (Test-Path -LiteralPath $statePath) {
        throw 'A diagnostic session already exists. Use -Action Restore first; the original settings are preserved.'
    }
    $saved = @{}
    foreach ($key in $keys) { $saved[$key] = [WestsideCrashIni]::Read($IniPath, $key) }
    $backup = $IniPath + '.westside-dump-' + [Guid]::NewGuid().ToString('N') + '.bak'
    [IO.File]::Copy($IniPath, $backup, $false)
    $state = [ordered]@{ Schema = 1; IniPath = $IniPath; Backup = $backup; Saved = $saved }
    $json = $state | ConvertTo-Json -Depth 4
    $stream = [IO.File]::Open($statePath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($json)
        $stream.Write($bytes, 0, $bytes.Length)
    } finally { $stream.Dispose() }

    try {
        foreach ($key in $keys) { [WestsideCrashIni]::Write($IniPath, $key, '1', $false) }
    } catch {
        throw "Could not enable diagnostics completely. Backup and restore state remain at $statePath. $($_.Exception.Message)"
    }
    Write-Output 'Full dumps enabled; automatic crash upload disabled for this diagnostic session.'
    Write-Output 'Restart ADMIN, reproduce once, and retain the new *-full.dmp plus that session log.'
    Write-Output 'Allow several GB of free space. Keep dumps private; do not upload them to GitHub.'
    Write-Output 'After capturing, close WESTSIDE and run this script with -Action Restore.'
    Write-Output "Configuration backup: $backup"
} else {
    if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) {
        throw 'No saved diagnostic session exists for this INI. Nothing was changed.'
    }
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    if ($state.Schema -ne 1 -or $state.IniPath -ine $IniPath) {
        throw 'Restore state does not match this configuration. Nothing was changed.'
    }
    # Restore only our two keys, never replace later edits to the whole INI.
    foreach ($key in $keys) {
        $current = [WestsideCrashIni]::Read($IniPath, $key)
        if ($current -cne '1' -and $current -cne $state.Saved.$key) {
            throw "$key changed since diagnostics were enabled. Refusing to overwrite that change."
        }
    }
    foreach ($key in $keys) {
        $value = $state.Saved.$key
        [WestsideCrashIni]::Write($IniPath, $key, $value, ($null -eq $value))
    }
    $archive = $statePath + '.restored-' + [Guid]::NewGuid().ToString('N')
    [IO.File]::Move($statePath, $archive)
    Write-Output 'Original diagnostic/upload settings restored. Other INI settings were left intact.'
}
